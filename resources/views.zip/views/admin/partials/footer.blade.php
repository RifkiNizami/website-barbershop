<footer class="admin-footer">
    <span>Rusdi Barbershop © {{ date('Y') }}</span>
    <div class="admin-footer-right">
        <span class="footer-status">
            <span class="footer-status-dot"></span> System Ready
        </span>
        <a href="{{ url('/') }}" target="_blank" class="footer-site-link">
            Lihat Website
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
        </a>
    </div>
</footer>